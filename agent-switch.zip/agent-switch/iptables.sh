#!/bin/bash
sudo iptables -t nat -F

#switch
sudo iptables -t nat -A PREROUTING -p tcp --dport 3333 -j REDIRECT --to 2222 --random
sudo iptables -t nat -A PREROUTING -p tcp --dport 8888 -j REDIRECT --to 2222 --random

sudo iptables -t nat -L -n
sudo service iptables-persistent save
